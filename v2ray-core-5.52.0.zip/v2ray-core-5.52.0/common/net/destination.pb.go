package net

import (
	protoreflect "google.golang.org/protobuf/reflect/protoreflect"
	protoimpl "google.golang.org/protobuf/runtime/protoimpl"
	reflect "reflect"
	sync "sync"
	unsafe "unsafe"
)

const (
	// Verify that this generated code is sufficiently up-to-date.
	_ = protoimpl.EnforceVersion(20 - protoimpl.MinVersion)
	// Verify that runtime/protoimpl is sufficiently up-to-date.
	_ = protoimpl.EnforceVersion(protoimpl.MaxVersion - 20)
)

// Endpoint of a network connection.
type Endpoint struct {
	state         protoimpl.MessageState `protogen:"open.v1"`
	Network       Network                `protobuf:"varint,1,opt,name=network,proto3,enum=v2ray.core.common.net.Network" json:"network,omitempty"`
	Address       *IPOrDomain            `protobuf:"bytes,2,opt,name=address,proto3" json:"address,omitempty"`
	Port          uint32                 `protobuf:"varint,3,opt,name=port,proto3" json:"port,omitempty"`
	unknownFields protoimpl.UnknownFields
	sizeCache     protoimpl.SizeCache
}

func (x *Endpoint) Reset() {
	*x = Endpoint{}
	mi := &file_common_net_destination_proto_msgTypes[0]
	ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
	ms.StoreMessageInfo(mi)
}

func (x *Endpoint) String() string {
	return protoimpl.X.MessageStringOf(x)
}

func (*Endpoint) ProtoMessage() {}

func (x *Endpoint) ProtoReflect() protoreflect.Message {
	mi := &file_common_net_destination_proto_msgTypes[0]
	if x != nil {
		ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
		if ms.LoadMessageInfo() == nil {
			ms.StoreMessageInfo(mi)
		}
		return ms
	}
	return mi.MessageOf(x)
}

// Deprecated: Use Endpoint.ProtoReflect.Descriptor instead.
func (*Endpoint) Descriptor() ([]byte, []int) {
	return file_common_net_destination_proto_rawDescGZIP(), []int{0}
}

func (x *Endpoint) GetNetwork() Network {
	if x != nil {
		return x.Network
	}
	return Network_Unknown
}

func (x *Endpoint) GetAddress() *IPOrDomain {
	if x != nil {
		return x.Address
	}
	return nil
}

func (x *Endpoint) GetPort() uint32 {
	if x != nil {
		return x.Port
	}
	return 0
}

var File_common_net_destination_proto protoreflect.FileDescriptor

const file_common_net_destination_proto_rawDesc = "" +
	"\n" +
	"\x1ccommon/net/destination.proto\x12\x15v2ray.core.common.net\x1a\x18common/net/network.proto\x1a\x18common/net/address.proto\"\x95\x01\n" +
	"\bEndpoint\x128\n" +
	"\anetwork\x18\x01 \x01(\x0e2\x1e.v2ray.core.common.net.NetworkR\anetwork\x12;\n" +
	"\aaddress\x18\x02 \x01(\v2!.v2ray.core.common.net.IPOrDomainR\aaddress\x12\x12\n" +
	"\x04port\x18\x03 \x01(\rR\x04portB`\n" +
	"\x19com.v2ray.core.common.netP\x01Z)github.com/v2fly/v2ray-core/v5/common/net\xaa\x02\x15V2Ray.Core.Common.Netb\x06proto3"

var (
	file_common_net_destination_proto_rawDescOnce sync.Once
	file_common_net_destination_proto_rawDescData []byte
)

func file_common_net_destination_proto_rawDescGZIP() []byte {
	file_common_net_destination_proto_rawDescOnce.Do(func() {
		file_common_net_destination_proto_rawDescData = protoimpl.X.CompressGZIP(unsafe.Slice(unsafe.StringData(file_common_net_destination_proto_rawDesc), len(file_common_net_destination_proto_rawDesc)))
	})
	return file_common_net_destination_proto_rawDescData
}

var file_common_net_destination_proto_msgTypes = make([]protoimpl.MessageInfo, 1)
var file_common_net_destination_proto_goTypes = []any{
	(*Endpoint)(nil),   // 0: v2ray.core.common.net.Endpoint
	(Network)(0),       // 1: v2ray.core.common.net.Network
	(*IPOrDomain)(nil), // 2: v2ray.core.common.net.IPOrDomain
}
var file_common_net_destination_proto_depIdxs = []int32{
	1, // 0: v2ray.core.common.net.Endpoint.network:type_name -> v2ray.core.common.net.Network
	2, // 1: v2ray.core.common.net.Endpoint.address:type_name -> v2ray.core.common.net.IPOrDomain
	2, // [2:2] is the sub-list for method output_type
	2, // [2:2] is the sub-list for method input_type
	2, // [2:2] is the sub-list for extension type_name
	2, // [2:2] is the sub-list for extension extendee
	0, // [0:2] is the sub-list for field type_name
}

func init() { file_common_net_destination_proto_init() }
func file_common_net_destination_proto_init() {
	if File_common_net_destination_proto != nil {
		return
	}
	file_common_net_network_proto_init()
	file_common_net_address_proto_init()
	type x struct{}
	out := protoimpl.TypeBuilder{
		File: protoimpl.DescBuilder{
			GoPackagePath: reflect.TypeOf(x{}).PkgPath(),
			RawDescriptor: unsafe.Slice(unsafe.StringData(file_common_net_destination_proto_rawDesc), len(file_common_net_destination_proto_rawDesc)),
			NumEnums:      0,
			NumMessages:   1,
			NumExtensions: 0,
			NumServices:   0,
		},
		GoTypes:           file_common_net_destination_proto_goTypes,
		DependencyIndexes: file_common_net_destination_proto_depIdxs,
		MessageInfos:      file_common_net_destination_proto_msgTypes,
	}.Build()
	File_common_net_destination_proto = out.File
	file_common_net_destination_proto_goTypes = nil
	file_common_net_destination_proto_depIdxs = nil
}
