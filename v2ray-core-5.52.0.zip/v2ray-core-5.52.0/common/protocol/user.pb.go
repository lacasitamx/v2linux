package protocol

import (
	protoreflect "google.golang.org/protobuf/reflect/protoreflect"
	protoimpl "google.golang.org/protobuf/runtime/protoimpl"
	anypb "google.golang.org/protobuf/types/known/anypb"
	reflect "reflect"
	sync "sync"
	unsafe "unsafe"
)

const (
	// Verify that this generated code is sufficiently up-to-date.
	_ = protoimpl.EnforceVersion(20 - protoimpl.MinVersion)
	// Verify that runtime/protoimpl is sufficiently up-to-date.
	_ = protoimpl.EnforceVersion(protoimpl.MaxVersion - 20)
)

// User is a generic user for all procotols.
type User struct {
	state protoimpl.MessageState `protogen:"open.v1"`
	Level uint32                 `protobuf:"varint,1,opt,name=level,proto3" json:"level,omitempty"`
	Email string                 `protobuf:"bytes,2,opt,name=email,proto3" json:"email,omitempty"`
	// Protocol specific account information. Must be the account proto in one of
	// the proxies.
	Account       *anypb.Any `protobuf:"bytes,3,opt,name=account,proto3" json:"account,omitempty"`
	unknownFields protoimpl.UnknownFields
	sizeCache     protoimpl.SizeCache
}

func (x *User) Reset() {
	*x = User{}
	mi := &file_common_protocol_user_proto_msgTypes[0]
	ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
	ms.StoreMessageInfo(mi)
}

func (x *User) String() string {
	return protoimpl.X.MessageStringOf(x)
}

func (*User) ProtoMessage() {}

func (x *User) ProtoReflect() protoreflect.Message {
	mi := &file_common_protocol_user_proto_msgTypes[0]
	if x != nil {
		ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
		if ms.LoadMessageInfo() == nil {
			ms.StoreMessageInfo(mi)
		}
		return ms
	}
	return mi.MessageOf(x)
}

// Deprecated: Use User.ProtoReflect.Descriptor instead.
func (*User) Descriptor() ([]byte, []int) {
	return file_common_protocol_user_proto_rawDescGZIP(), []int{0}
}

func (x *User) GetLevel() uint32 {
	if x != nil {
		return x.Level
	}
	return 0
}

func (x *User) GetEmail() string {
	if x != nil {
		return x.Email
	}
	return ""
}

func (x *User) GetAccount() *anypb.Any {
	if x != nil {
		return x.Account
	}
	return nil
}

var File_common_protocol_user_proto protoreflect.FileDescriptor

const file_common_protocol_user_proto_rawDesc = "" +
	"\n" +
	"\x1acommon/protocol/user.proto\x12\x1av2ray.core.common.protocol\x1a\x19google/protobuf/any.proto\"b\n" +
	"\x04User\x12\x14\n" +
	"\x05level\x18\x01 \x01(\rR\x05level\x12\x14\n" +
	"\x05email\x18\x02 \x01(\tR\x05email\x12.\n" +
	"\aaccount\x18\x03 \x01(\v2\x14.google.protobuf.AnyR\aaccountBo\n" +
	"\x1ecom.v2ray.core.common.protocolP\x01Z.github.com/v2fly/v2ray-core/v5/common/protocol\xaa\x02\x1aV2Ray.Core.Common.Protocolb\x06proto3"

var (
	file_common_protocol_user_proto_rawDescOnce sync.Once
	file_common_protocol_user_proto_rawDescData []byte
)

func file_common_protocol_user_proto_rawDescGZIP() []byte {
	file_common_protocol_user_proto_rawDescOnce.Do(func() {
		file_common_protocol_user_proto_rawDescData = protoimpl.X.CompressGZIP(unsafe.Slice(unsafe.StringData(file_common_protocol_user_proto_rawDesc), len(file_common_protocol_user_proto_rawDesc)))
	})
	return file_common_protocol_user_proto_rawDescData
}

var file_common_protocol_user_proto_msgTypes = make([]protoimpl.MessageInfo, 1)
var file_common_protocol_user_proto_goTypes = []any{
	(*User)(nil),      // 0: v2ray.core.common.protocol.User
	(*anypb.Any)(nil), // 1: google.protobuf.Any
}
var file_common_protocol_user_proto_depIdxs = []int32{
	1, // 0: v2ray.core.common.protocol.User.account:type_name -> google.protobuf.Any
	1, // [1:1] is the sub-list for method output_type
	1, // [1:1] is the sub-list for method input_type
	1, // [1:1] is the sub-list for extension type_name
	1, // [1:1] is the sub-list for extension extendee
	0, // [0:1] is the sub-list for field type_name
}

func init() { file_common_protocol_user_proto_init() }
func file_common_protocol_user_proto_init() {
	if File_common_protocol_user_proto != nil {
		return
	}
	type x struct{}
	out := protoimpl.TypeBuilder{
		File: protoimpl.DescBuilder{
			GoPackagePath: reflect.TypeOf(x{}).PkgPath(),
			RawDescriptor: unsafe.Slice(unsafe.StringData(file_common_protocol_user_proto_rawDesc), len(file_common_protocol_user_proto_rawDesc)),
			NumEnums:      0,
			NumMessages:   1,
			NumExtensions: 0,
			NumServices:   0,
		},
		GoTypes:           file_common_protocol_user_proto_goTypes,
		DependencyIndexes: file_common_protocol_user_proto_depIdxs,
		MessageInfos:      file_common_protocol_user_proto_msgTypes,
	}.Build()
	File_common_protocol_user_proto = out.File
	file_common_protocol_user_proto_goTypes = nil
	file_common_protocol_user_proto_depIdxs = nil
}
